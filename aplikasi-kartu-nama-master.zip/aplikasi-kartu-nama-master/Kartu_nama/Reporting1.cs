﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Kartu_nama
{
    public partial class Reporting1 : Form
    {
        public Reporting1()
        {
            InitializeComponent();
        }

        Konektor koneksi = new Konektor();

        private void Reporting1_Load(object sender, EventArgs e)
        {
            
        }
    }
}
